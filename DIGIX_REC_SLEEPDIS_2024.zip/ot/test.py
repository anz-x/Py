import pandas as pd
import torch
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import kneighbors_graph

# 加载数据集
data = pd.read_csv('ot/atest.csv')

# 数据预处理
features = data.drop('diagnosis', axis=1)  # 特征
labels = data['diagnosis'].values  # 标签

# 标准化特征
scaler = StandardScaler()
features = scaler.fit_transform(features)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)

# 计算训练集和测试集的样本数量
num_train_samples = X_train.shape[0]
num_test_samples = X_test.shape[0]

# 确保k不超过样本数量
k = min(5, num_train_samples)  # 对于训练集
k_test = min(5, num_test_samples)  # 对于测试集

# 构建训练集的邻接矩阵
adjacency_matrix = kneighbors_graph(X_train, n_neighbors=k, mode='connectivity', include_self=True).toarray()
edge_index = np.array(np.nonzero(adjacency_matrix))  # 转换为edge_index格式

# 创建PyTorch Geometric数据对象
train_data = Data(x=torch.tensor(X_train, dtype=torch.float), edge_index=torch.tensor(edge_index, dtype=torch.long), y=torch.tensor(y_train, dtype=torch.long))

# 定义GNN模型
class GNNModel(torch.nn.Module):
    def __init__(self):
        super(GNNModel, self).__init__()
        self.conv1 = GCNConv(in_channels=X_train.shape[1], out_channels=64)
        self.conv2 = GCNConv(in_channels=64, out_channels=32)
        self.fc = torch.nn.Linear(32, 55)  # 假设有10个类别

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = self.fc(x)
        return F.log_softmax(x, dim=1)

# 加载模型
model = GNNModel()
model.load_state_dict(torch.load('ot/gnn_model.pth', weights_only=True), strict=False)
model.eval()  # 切换到评估模式
print("models is loaded!")

# 评估模型
model.eval()
with torch.no_grad():
    # 构建测试数据的邻接矩阵
    adjacency_matrix_test = kneighbors_graph(X_test, n_neighbors=k_test, mode='connectivity', include_self=True).toarray()
    edge_index_test = np.array(np.nonzero(adjacency_matrix_test))  # 转换为edge_index格式
    test_data = Data(x=torch.tensor(X_test, dtype=torch.float), edge_index=torch.tensor(edge_index_test, dtype=torch.long), y=torch.tensor(y_test, dtype=torch.long))
    
    pred = model(test_data).max(dim=1)[1]  # 获取预测类别
    accuracy = (pred == test_data.y).sum().item() / test_data.y.size(0)
    print(f'mean accuracy: {accuracy:.2f}')

# # 进行预测
# new_data = pd.read_csv('ot/chk.csv')
# new_data_scaled = scaler.transform(new_data)

# # 构建新数据的邻接矩阵
# adjacency_matrix_new = kneighbors_graph(new_data_scaled, n_neighbors=min(5, new_data_scaled.shape[0]), mode='connectivity', include_self=True).toarray()
# edge_index_new = np.array(np.nonzero(adjacency_matrix_new))  # 转换为edge_index格式
# new_data_tensor = Data(x=torch.tensor(new_data_scaled, dtype=torch.float), edge_index=torch.tensor(edge_index_new, dtype=torch.long))

# model.eval()
# # with torch.no_grad():
# #     pred = model(new_data_tensor).max(dim=1)[1]  # 获取预测类别

# # # 打印预测结果
# # print("diagnosis:", pred.numpy())
# # 获取模型输出的概率
# output = model(new_data_tensor)

# # 获取前5个概率和对应的类别
# top5_prob, top5_pred = torch.topk(F.softmax(output, dim=1), k=5)

# # 打印前5个预测结果及其概率
# for i in range(top5_pred.size(0)):
#     # print(f"Sample {i+1}:")
#     for j in range(5):
#         print(f"Class: {top5_pred[i][j].item()}")
# 进行预测
new_data = pd.read_csv('ot/chk.csv')
new_data_scaled = scaler.transform(new_data)

# 构建新数据的邻接矩阵
adjacency_matrix_new = kneighbors_graph(new_data_scaled, n_neighbors=min(5, new_data_scaled.shape[0]), mode='connectivity', include_self=True).toarray()
edge_index_new = np.array(np.nonzero(adjacency_matrix_new))  # 转换为edge_index格式
new_data_tensor = Data(x=torch.tensor(new_data_scaled, dtype=torch.float), edge_index=torch.tensor(edge_index_new, dtype=torch.long))

model.eval()
with torch.no_grad():
    # 获取模型输出的概率
    output = model(new_data_tensor)

    # 获取前5个概率和对应的类别
    top5_prob, top5_pred = torch.topk(F.softmax(output, dim=1), k=5)

    # 绘制图形
    for i in range(top5_pred.size(0)):
        plt.figure(figsize=(8, 4))
        plt.bar(range(5), top5_prob[i].numpy(), align='center', alpha=0.7)
        plt.xticks(range(5), top5_pred[i].numpy(), rotation=45)
        plt.xlabel('Predicted Classes')
        plt.ylabel('Probabilities')
        plt.title(f'Sample {i+1}: Top 5 Predicted Classes')
        plt.ylim(0, 0.05)
        plt.grid(axis='y')

        # 显示图像
        plt.show()  # 直接显示图像