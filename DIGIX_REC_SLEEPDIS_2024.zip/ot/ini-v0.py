import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.utils import to_categorical

# 加载数据集
data = pd.read_csv('gnn_enh_think\ot\sleep_data.csv')

# 数据预处理
features = data.drop('diagnosis', axis=1)  # 特征
labels = data['diagnosis']  # 标签

# 将标签转换为多类格式
labels = to_categorical(labels, num_classes=10)  # 假设有10个类别

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)

# 标准化特征
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# 构建模型
model = Sequential()
model.add(Dense(64, activation='relu', input_shape=(X_train.shape[1],)))
model.add(Dense(32, activation='relu'))
model.add(Dense(10, activation='softmax'))  # 输出层改为10个神经元，激活函数为softmax

# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])  # 损失函数改为categorical_crossentropy

# 训练模型
model.fit(X_train, y_train, epochs=50, batch_size=10, validation_split=0.2)

# 评估模型
loss, accuracy = model.evaluate(X_test, y_test)
print(f'Test Accuracy: {accuracy:.2f}')

# 进行预测
new_data = pd.read_csv('gnn_enh_think\ot\\n_sleep_data.csv')
new_data_scaled = scaler.transform(new_data)
predictions = model.predict(new_data_scaled)

# 将预测结果转换为标签
predicted_labels = predictions.argmax(axis=1)  # 获取每个样本的最大概率对应的类别
print('predict end:')
print(predicted_labels)