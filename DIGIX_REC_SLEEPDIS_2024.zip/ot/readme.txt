先cd进入ot的父目录再运行

python test.py